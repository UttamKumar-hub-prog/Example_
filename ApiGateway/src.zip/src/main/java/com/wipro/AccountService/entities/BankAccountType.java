package com.wipro.AccountService.entities;

public enum BankAccountType {
	CURRENT, SAVINGS, SALARY

}
