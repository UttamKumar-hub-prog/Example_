package com.wipro.FeedbackService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
