package com.wipro.PaymentService.entities;

public enum PaymentStatus {
	SUCCESS, PENDING, FAILED

}
